var fullscreen = 0;
